<?php

// Include file with sql details
	$host = "feenix-mariadb.swin.edu.au";
	$user = "s102240620";
	$pwd  = "130600";
	$sql_db  = "s102240620_db";

?>