<?php
    session_start();
	if(!isset($_SESSION["number"])){
		$_SESSION["number"] = rand(1,100);

	}
	if(!isset($_SESSION["count"])){
		$_SESSION["count"] = 0;
	}

?>
<!DOCTYPE html>
<html lang= "en">
<head>
    <meta charset = "utf-8" />
	<meta name = "description" content="Lab10 PHP" /> 
	<title>Lab 10 PHP SESSION TASK 2 </title>
</head>
<body>
	<h1>Guessing Game</h1>
	<p><strong>Enter a number between 1 and 100, then press the Guess button</strong> </p>
	<br/>
	<form method = "post" action = "">
	    <input type ="text" name="guess" id = "guess"/>
		<input type ="submit" name="button" id = "Guess" />
	</form>	

	
	<?php
	    $number = $_SESSION["number"]; 
		$counter = $_SESSION["count"]; 	
		if(isset($_POST["guess"])){
			$guess = $_POST["guess"];
			if (is_numeric($guess) && ($guess > 0) && ($guess < 101)){
				if ($number > $guess){
					echo"<p> the correct number is lower. try again.</p>";

				}

				if ($number < $guess){
					echo"<p> the correct number is higher. try again.</p>";
					
				}

				if ($number == $guess){
					echo"<p> Congratulations.</p>";
					
				}
				$counter ++;
				$_SESSION["count"] = $counter;
			}else{
				echo"<p> The input error, please try again.</p>";
			}

			
		}
		echo"<p> Number of guesses: $counter.</p>";

	?>
		<a href="giveup.php" class="navi">Give Up</a>
		<a href="startover.php" class="navi">Start Over</a>
	

</body>
</html>

