<!DOCTYPE html>
<html lang="en">
<head>

        <meta charset = "utf-8"/>
        <meta name = "description" content = "Lab10 PHP"/>
</head> 

<body>
       <h1> GUESSING GAME </h1>
<?php
           session_start();
           echo "<p>THE HIDDEN NUMBER WAS ", $_SESSION["number"], "</p>";

?>

<p><a href="startover.php">Start Over</a></p>
</body>
</html>