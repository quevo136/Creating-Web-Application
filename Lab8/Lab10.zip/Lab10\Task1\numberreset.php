<?php
session_start();

header("location:number.php");
?>