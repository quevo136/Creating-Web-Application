<?php

// Include file with sql details
	$host = "feenix-mariadb.swin.edu.au";
	$user = "s1234567";
	$pwd  = "ddmmyy";
	$sql_db  = "s1234567_db";

?>