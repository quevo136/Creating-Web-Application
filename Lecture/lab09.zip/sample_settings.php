<?php
	$host = "feenix-mariadb.swin.edu.au";
	$user = "s1234567890"; // your user name
	$pwd = "ddmmyy"; // your password (date of birth ddmmyy unless changed)
	$sql_db = "s1234567890_db"; // your database
?>
	
	
	