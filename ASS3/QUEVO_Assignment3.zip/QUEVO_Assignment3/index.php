<!DOCTYPE html>
<html>
<head>
	<title>Introductory home page</title>
	<link href = "style.css" rel="stylesheet"/>
	<link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Arvo&family=Dosis&family=Lato&family=Open+Sans&family=Roboto&display=swap" rel="stylesheet">

    <meta name="viewport" content="width=device=width, initial-scale=1.0, maximum-scale=1"/>
    <link href = "responsive.css" rel="stylesheet" media= "screen and (max-width:1024px)"/>

</head>
<body>
	<header>
		
                <?php include 'menu.inc'; ?>
	</header>
	

	<a href="images/index2.jpg"><img src="images/index2.jpg" alt="index_img" style="width:100%;"/></a>
	
	
	<footer>
		<p>Assignment 1</p>
	</footer>

</body>
</html>