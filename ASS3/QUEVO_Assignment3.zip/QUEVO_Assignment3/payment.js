"use strict";
// form  info checking here
function checkCardNo() {
    var errMsg = ""; 
    var result = true;
    var ccnum = document.getElementById("ccnum").value;
    var fname = document.getElementById("fname").options[document.getElementById("fname").selectedIndex].text;


    var cardno;
 

  return result;

}

/*function storeBooking(firstName, lastName, Email,) {
  sessionStorage.firstname = firstName; //key = value
  sessionStorage.lastname = lastName;
  sessionStorage.email = email;
  sessionStorage.phone = species;
  var food = document.getElementById("food").value;
  sessionStorage.food = food;
  var beard = document.getElementById("beard").value;
  sessionStorage.beard = beard;
  var partySize = document.getElementById("partySize").value;
  sessionStorage.partySize = partySize;
  }

function calcCost(priceElement, quantityElement){
  var total = 0;
  if (cartItemNames.match("Design").cost = 109.99 ;
  if (cartItemNames.match("Computer Science").cost = 110.99 ;
  if (cartItemNames.match("Marketing").cost = 119.99 ;  
  if (cartItemNames.match("Business and Finance").cost = 106.99 ;    
  return total + (price * quantity);
}
*/

function getBooking(){
  var total = 0;
  if(sessionStorage.priceElement != undefined){ 
    document.getElementById("total").textContent = sessionStorage.total;
    document.getElementById("total").value = sessionStorage.total;
     
    document.getElementById("First_name").textContent = sessionStorage.firstName;
    document.getElementById("First_name").value = sessionStorage.firstName;

    document.getElementById("Last_name").textContent = sessionStorage.lastName;
    document.getElementById("Last_name").value = sessionStorage.lastName;

    document.getElementById("email").textContent = sessionStorage.email;
    document.getElementById("email").value = sessionStorage.email;

    document.getElementById("phone_num").textContent = sessionStorage.phoneNumber;
    document.getElementById("phone_num").value = sessionStorage.phoneNumber;    

    document.getElementById("street").textContent = sessionStorage.street;
    document.getElementById("street").value = sessionStorage.street;

    document.getElementById("Suburb").textContent = sessionStorage.suburb;
    document.getElementById("Suburb").value = sessionStorage.suburb;

    document.getElementById("postcode").textContent = sessionStorage.postCode;
    document.getElementById("postcode").value = sessionStorage.postCode;

    document.getElementById("ccnum").textContent = sessionStorage.cardnum;
    document.getElementById("ccnum").value = sessionStorage.cardnum;

    document.getElementById("cardname").textContent = sessionStorage.cardname;
    document.getElementById("cardname").value = sessionStorage.cardname;

    document.getElementById("expmonth").textContent = sessionStorage.expmonth;
    document.getElementById("expmonth").value = sessionStorage.expmonth;

    document.getElementById("expyear").textContent = sessionStorage.expyear;
    document.getElementById("expyear").value = sessionStorage.expyear;

    document.getElementById("cvv").textContent = sessionStorage.cvv;
    document.getElementById("cvv").value = sessionStorage.cvv;


    

    //if sessionStorage for username is not empty
    //confirmation text
    //document.getElementById("confirm_name").textContent = sessionStorage.firstname + " " + sessionStorage.lastname;
    //document.getElementById("container content-section").textContent = sessionStorage.cartItems;
    //document.getElementById("cart-item").textContent = sessionStorage.cartItemNames;
    document.getElementById("cart-price").textContent = sessionStorage.priceElement;
    document.getElementById("cart-quantity-input").textContent = sessionStorage.quantityElement;
   
    //document.getElementById(" ")textContent = sessionStorage.quantity;
    cost = calcCost(sessionStorage.trip, sessionStorage.partySize);
    total = calcCost(seesionStorage.priceElement, sessionStorage.quantityElement);
    document.getElementById("confirm_cost").textContent = total;
    //fill hidden fields

    //document.getElementById("container content-section").value = sessionStorage.cartItems;
    //document.getElementById("cart-item cart-header cart-column").value = sessionStorage.cartItemNames;
    document.getElementById("cart-price cart-header cart-column").value = sessionStorage.priceElement;
    document.getElementById("cart-quantity-input").value = sessionStorage.quantityElement;
    document.getElementById("confirm_cost").value = sessionStorage.totalPriceElement;


    /*
    Write lastname, age, species, age, food, and partySize from seesionStorage to the hidden inputs 
    
    document.getElementById("total").value = total;
  }*/
  }
}


function init(){

 // get ref to the HTML element
  var validation = document.getElementById("validation");
  //var regForm = document.getElementById("regform");
  validation.onsubmit = checkCardNo;
  //regForm.onsubmit = checkCardNo;
  getBooking();

  var cancel = document.getElementById("cancelButton");
  cancel.onclick = cancelBooking;


  
}

function cancelBooking() {
  window.location = "index.html";
}


window.onload = init;