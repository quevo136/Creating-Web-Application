"use strict";
// form  info checking here
function checkCardNo() {
    var errMsg = ""; 
    var result = true;
    var ccnum = document.getElementById("ccnum").value;
    var fname = document.getElementById("fname").options[document.getElementById("fname").selectedIndex].text;


    var cardno;
 
switch (fname) {
    case "Please Select":
        return false;
    case "AmericanExpress":
        cardno = new RegExp(/^(?:3[47][0-9]{13})$/);
        break;
     case "Visa":
        cardno = new RegExp(/^(?:4[0-9]{12}(?:[0-9]{3})?)$/);
        break;
     case "MasterCard":
        cardno = new RegExp(/^(?:5[1-5][0-9]{14})$/);
        break;
     

   if(!fname.match(cardno)){
   errMsg = errMsg + "Not a valid Visa credit card number!\n";
   result = false;
  }

 

  if (errMsg != "") { //only display message box if there is something to show
    alert(errMsg);
  }
  return result;

}

function calcCost(priceElement, quantityElement){
  var total = 0;
  if (cartItemNames.match("Design").cost = 109.99;
  else if (cartItemNames.match("Computer Science").cost = 110.99;
  else if  (cartItemNames.match("Marketing").cost = 119.99;  
  else (cartItemNames.match("Business and Finance").cost = 106.99;    
  return total + (price * quantity);
}


function getBooking(){
  var total = 0;
  if(sessionStorage.priceElement != undefined){    //if sessionStorage for username is not empty
    //confirmation text
    document.getElementById("cart-total-price").textContent = sessionStorage.totalPriceElement;
    document.getElementById("cart-total-price").value = sessionStorage.totalPriceElement;
    
    document.getElementById("Last_name").textContent = sessionStorage.lastname;
    //document.getElementById("container content-section").textContent = sessionStorage.cartItems;
    //document.getElementById("cart-item").textContent = sessionStorage.cartItemNames;
    document.getElementById("cart-price").textContent = sessionStorage.priceElement;
    document.getElementById("cart-quantity-input").textContent = sessionStorage.quantityElement;
   
    //document.getElementById(" ")textContent = sessionStorage.quantity;
    cost = calcCost(sessionStorage.trip, sessionStorage.partySize);
    total = calcCost(seesionStorage.priceElement, sessionStorage.quantityElement);
    document.getElementById("confirm_cost").textContent = total;
    //fill hidden fields

    //document.getElementById("container content-section").value = sessionStorage.cartItems;
    //document.getElementById("cart-item cart-header cart-column").value = sessionStorage.cartItemNames;
    document.getElementById("Last_name").value = sessionStorage.lastname;
    document.getElementById("cart-price cart-header cart-column").value = sessionStorage.priceElement;
    document.getElementById("cart-quantity-input").value = sessionStorage.quantityElement;
    document.getElementById("confirm_cost").value = sessionStorage.totalPriceElement;


    /*
    Write lastname, age, species, age, food, and partySize from seesionStorage to the hidden inputs 
    
    document.getElementById("total").value = total;*/
  }

}


function init(){
  getBooking();
  var validation = document.getElementById("validation");
  //var regForm = document.getElementById("regform");
  validation.onsubmit = checkCardNo;
 

  var cancel = document.getElementById("cancelButton");
  cancel.onclick = cancelBooking;

 
}

function cancelBooking() {
  window.location = "index.html";
}


window.onload = init;